/**
 * 全站路由配置
 *
 * meta参数说明
 * keepAlive是否缓冲页面
 * isTab是否加入到tag导航
 * isAuth是否需要授权
 */
import Vue from 'vue'
import VueRouter from 'vue-router';
import PageRouter from './page/'
Vue.use(VueRouter)
const Router = new VueRouter({
  base: process.env.VUE_APP_BASE_URL,
  mode: 'history',
  routes: [...PageRouter]
})

export default Router