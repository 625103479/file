import Vue from 'vue';
import axios from './router/axios';
import VueAxios from 'vue-axios';
import App from './App';
import router from './router/router';

import Element from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import AVUE from '@smallwei/avue'
import '@smallwei/avue/lib/index.css'
import basicBlock from './components/basic-block/main'
import basicContainer from './components/basic-container/main'
import dayjs from 'dayjs'
Vue.prototype.$dayjs = dayjs
Vue.config.productionTip = false;
Vue.use(VueAxios, axios)
Vue.use(Element)
Vue.use(AVUE)
//注册全局容器
Vue.component('basicContainer', basicContainer)
Vue.component('basicBlock', basicBlock)

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')